import os


#install library
os.system("py -m pip install numpy")
os.system("py -m pip install pandas")
os.system("py -m pip install matplotlib")
os.system("py -m pip install tqdm")
os.system('cls')