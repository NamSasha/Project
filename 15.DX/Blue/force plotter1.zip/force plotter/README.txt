1, Install pycharm and python tool followed Manual.

2, Input shear log into "log folder".
Please note: the format of log file should be .csv or .CSV

*\force plotter\log

3, Run "force plot tool"

4, Take result in "result folder".

Cheer up!