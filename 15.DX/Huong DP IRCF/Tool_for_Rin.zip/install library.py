import os


#install library
os.system("py -m pip install pandas")
os.system("py -m pip install openpyxl")
os.system("py -m pip install tqdm")
os.system("py -m pip install pywin32")
os.system('cls')